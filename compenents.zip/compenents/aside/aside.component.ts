import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aside',
  templateUrl: './aside.component.html',
  styleUrls: ['./aside.component.scss']
})
export class AsideComponent implements OnInit {
  aside=[{
    name:'Baarish Ban Ja',
    img:'../../assets/baarish.jpg'
  },{
    name:'Filhall',
    img:'../../assets/filhall.jfif'
  },
  {
    name:'Shayad',
    img:'../../assets/shayad.jfif'
  },
  {
    name:'Ghungroo',
    img:'../../assets/ghungroo.jfif'
  }]
  constructor() { }

  ngOnInit(): void {
  }

}

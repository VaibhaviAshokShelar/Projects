import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-abouts',
  templateUrl: './abouts.component.html',
  styleUrls: ['./abouts.component.scss']
})
export class AboutsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

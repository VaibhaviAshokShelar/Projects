import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-detailsmusic',
  templateUrl: './detailsmusic.component.html',
  styleUrls: ['./detailsmusic.component.scss']
})
export class DetailsmusicComponent implements OnInit {

  id:any;
  constructor(private _activeRoute:ActivatedRoute) {
//this.id=_activeRoute.snapshot.params.id;
_activeRoute.params.subscribe(p=>{
  this.id=p.id;
});
   }

  ngOnInit(): void {
  }

}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DetailsmusicComponent } from './detailsmusic.component';

describe('DetailsmusicComponent', () => {
  let component: DetailsmusicComponent;
  let fixture: ComponentFixture<DetailsmusicComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DetailsmusicComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DetailsmusicComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

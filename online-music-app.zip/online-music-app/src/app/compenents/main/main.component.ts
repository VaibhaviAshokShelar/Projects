import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.scss']
})
export class MainComponent implements OnInit {
  music=[{
    musicId:'1',
    musicName:'Faded',
    musicGenre:'Pop',
    musicImage:'../../assets/faded.jpg',
    musicFile:'../../assets/alan walker fade ncs release - [Free Music Downloads].mp3',
    musicSinger:'Alan Walker'
  },{
    musicId:'2',
    musicName:'Cheap Thrills',
    musicGenre:'Pop',
    musicImage:'../../assets/cheap.png',
    musicFile:'../../assets/Cheap Thrills (feat. Sean Paul) (Mp3Beet.Com) - 192Kbps.mp3',
    musicSinger:' Sean Paul'

  }]

  colors=["red","green","yellow"]
  favorite:Array<any>=[]
  color:string=""
  audio: any= new Audio();
  public show:boolean = false;
  play(m:any)
    {
        if(this.color==""){
        this.color="first";
        this.audio.src = m.musicFile;
        this.audio.load();
        this.audio.play();}
    }
    stop(m:any)
    {
        this.audio.load();
        this.audio.stop();
    }

    search=""

    fav(m:object){
      this.favorite.push(m);
      console.log(this.favorite);
    }

    searchAndPlay(){
      this.music.forEach(element => {
        if(element.musicName==this.search)
        this.play(element);
      });
      console.log(this.search);
    }

  constructor(private _router: Router) { }

  ngOnInit(): void {
  }

  mid:any;
  navigateTo(mid : any){
    this._router.navigate(['/musics/'+mid]);
  }
}

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-addmusic',
  templateUrl: './addmusic.component.html',
  styleUrls: ['./addmusic.component.scss']
})
export class AddmusicComponent implements OnInit {

  musicForm: FormGroup;
  constructor(private fb:FormBuilder) {
    this.musicForm=this.fb.group({
      musicName: ['',Validators.required],
      movieCategory: ['',Validators.required]
    })
   }

  ngOnInit(): void {
  }
  OnAddMusic(form: FormGroup) {
    console.log('Valid?', form.valid); // true or false
    console.log('musicName', form.value.musicName);
    console.log('movieCategory', form.value.movieCategory);
  }
}

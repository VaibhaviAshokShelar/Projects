import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainComponent } from './compenents/main/main.component';
import { AboutsComponent } from './compenents/abouts/abouts.component';
import { ContactusComponent } from './compenents/contactus/contactus.component';
import {DetailsmusicComponent} from './compenents/detailsmusic/detailsmusic.component';
import {AddmusicComponent} from './compenents/addmusic/addmusic.component';
import {PagenotfoundComponent} from './compenents/pagenotfound/pagenotfound.component';
import { LoginformComponent } from './compenents/loginform/loginform.component';

const routes: Routes = [
  {path:'login',component:LoginformComponent},
  {path:'music',component:MainComponent},
  {path:'musics/:id',component:DetailsmusicComponent},
  {path:'aboutus',component:AboutsComponent},
  {path:'contactus',component:ContactusComponent},
  {path:'addmusic',component:AddmusicComponent},
  {path:'',redirectTo:'music',pathMatch:'full'},
  {path:'**',component:PagenotfoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

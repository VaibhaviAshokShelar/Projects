import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './compenents/header/header.component';
import { MainComponent } from './compenents/main/main.component';
import { FooterComponent } from './compenents/footer/footer.component';
import { AsideComponent } from './compenents/aside/aside.component';
import {NavComponent} from './compenents/nav/nav.component';
import { AboutsComponent } from './compenents/abouts/abouts.component';
import { ContactusComponent } from './compenents/contactus/contactus.component';
import { DetailsmusicComponent } from './compenents/detailsmusic/detailsmusic.component';
import { AddmusicComponent } from './compenents/addmusic/addmusic.component';
import { PagenotfoundComponent } from './compenents/pagenotfound/pagenotfound.component';
import { LoginformComponent } from './compenents/loginform/loginform.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    MainComponent,
    FooterComponent,
    AsideComponent,
    NavComponent,
    AboutsComponent,
    ContactusComponent,
    DetailsmusicComponent,
    AddmusicComponent,
    PagenotfoundComponent,
    LoginformComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
